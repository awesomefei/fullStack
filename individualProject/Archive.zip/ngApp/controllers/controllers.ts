namespace individualProject.Controllers {

    export class HomeController {
        public message = 'Welcome to WOW restaurant!';

    }


    export class AboutController {
        public message = 'Hello from the about page!';
    }



}
